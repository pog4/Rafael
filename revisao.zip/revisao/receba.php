<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<?php
    echo "<h1><a href='index.php'>Index</a></h1>";
    echo "Nome: ".$_POST['nome']."<br> <br>";
    echo "Salário: ".$_POST['salario']."<br> <br>";
    echo "Endereço: ".$_POST['endereco'];
    receba();

    function receba(){

        $valido = true;

        if (empty($_POST['nome'])) {
            echo "<h3>Falta nome</h3>";
            $valido = false;

        }if (empty($_POST['endereco'])) {
            echo "<h3>Falta endereço</h3>";
            $valido = false;

        }

       if ($valido == true) {
        
            $minimos = ($_POST['salario'] / 1212);
            echo "<br> <br>";
            echo "O seu salário equivale a ".$minimos." Salários mínimos.";

       } else {
            echo "<h3>Refassa o formulário</h3>";
       }



    }



?>

</body>
</html>
