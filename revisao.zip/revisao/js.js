/*function mostramsg(msg) {
    document.getElementById("msg").innerHTML = msg; 
    setTimeout(() => {
       document.getElementById("msg").innerHTML = ""; 
    }, 3000);
}*/


function confirma() {

    let salario = document.getElementById('salario').value;


    if (!parseInt(salario)) {
        document.write("<a href='index.php'><h3>Voltar</h3></a>")
        document.write("<h1>Salário tem que ter apenas números</h1>")
        
    }else if (salario <= 0) {
        
        document.write("<a href='index.php'><h3>Voltar</h3></a>")
        document.write("<a href='index.php'><h1>Salário tem que ser maior que 0</h1></a>")
        
    }
}