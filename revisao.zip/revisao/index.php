<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script language="JavaScript" src="js.js"></script>
    
</head>
<body>
    
 <form method="post" action="receba.php" onsubmit="confirma()" onsubmit="return receba()">

    Nome:     <input type="text" id="nome" name="nome"> <br>
    Salário:  <input type="text" id="salario" name="salario"> <br>
    Endereço: <br><textarea type="text" id="endereco" name="endereco" cols="30" rows="10"></textarea> <br> <br>

    <input type="submit">

 </form>

 <br> <br> <br> <br>
 

</body>
</html>